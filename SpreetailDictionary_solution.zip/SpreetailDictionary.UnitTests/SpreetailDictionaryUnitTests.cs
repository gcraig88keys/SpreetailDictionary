using Moq;
using Xunit;
using SpreetailDictionary;
using SpreetailDictionary.Interfaces;
using SpreetailDictionary.App;
using System.Collections.Generic;


namespace SpreetailDictionary.UnitTests
{
        public class SpreetailDictionaryUnitTests
    {
        private readonly Mock<ISpreetailDictionary> _mockSpreetailDictionary;

        public SpreetailDictionaryUnitTests()
        {
            Mock<ISpreetailDictionary> _mockSpreetailDictionary = new Mock<ISpreetailDictionary>();
        }


        [Fact]
        public void TestAddValuesOk()
        {

            //Arrange
            string expectedKey = "foo";
            List<string> expectedValues = new List<string>();
            expectedValues.Add("beq");
            expectedValues.Add("bev");
            //_mockSpreetailDictionary.Setup(m => m.AddValue("foo", "beq"));
            //_mockSpreetailDictionary.Setup(m => m.AddValue("foo", "bev"));
            //_mockSpreetailDictionary.Object.
            _mockSpreetailDictionary.Object.AddValue("foo", "beq");
            _mockSpreetailDictionary.Object.AddValue("foo", "beq");


            //Act 
            var actualKey = _mockSpreetailDictionary.Object.OurDictionary.Keys.ToString();
            var actualValues = _mockSpreetailDictionary.Object.OurDictionary;

            //Assert 
            Assert.True(expectedKey == actualKey);
           // Assert.True(expectedValues == actualValues);


            
           
           //Act 

           //Assert 
        }
    }
}
