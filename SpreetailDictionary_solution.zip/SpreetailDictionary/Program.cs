﻿using System;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using SpreetailDictionary.App;
using SpreetailDictionary.Interfaces;

namespace SpreetailDictionary.App
{
    class Program
    {
        static void Main(string[] args)
        {
            IServiceCollection services = new ServiceCollection();
            Startup startup = new Startup();
            startup.ConfigureServices(services);
            IServiceProvider serviceProvider = services.BuildServiceProvider();

            SpreetailDictionary myDictionary = new SpreetailDictionary();
            
            
            string command = string.Empty;
            string status = string.Empty;
            string action = string.Empty;
            string key = string.Empty;
            string value = string.Empty;
            
            do
            {
                command = string.Empty; // command as enterd by user
                action = string.Empty;  // command verb
                key = string.Empty;     // command dictionary key
                value = string.Empty;   // command dictionary vlaue
                
                // Console Commmand prompt and input
                Console.WriteLine("Enter Command: KEYS, MEMBERS, ADD, REMOVE, REMOVEALL, CLEAR, KEYEXISTS, MEMBEREXISTS, ALLMEMBERS, ITEMS,");
                Console.WriteLine("or Q to stop");
                command = Console.ReadLine();

                //Split command on blanks into array
                string[] commandparts = command.Split(' ');

                // check for number of array elements and move array entries into variables for processing
                // ... command action
                if (commandparts.Length > 0)
                {
                    action = commandparts[0];
                }

                // ... command key
                if (commandparts.Length > 1)
                {
                    key = commandparts[1];
                }

                // ... command value (member)
                if (commandparts.Length > 2)
                {
                    value = commandparts[2];
                }

                // Handle ADD command
                if (action == "ADD")
                {
                    // Insure required command parameters are populated
                    if (!string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(key))
                    {
                        try
                        {
                            myDictionary.AddValue(key, value);  // add they key/value pair to the dictionary
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                    }

                    else
                    {
                        // display error if ADD command is incomplete
                        Console.WriteLine("ERROR: ADD command is incomplete. It must contain a dictionary key and value");
                    }

                }

                // Handle REMOVE Command
                else if (action == "REMOVE")
                {
                    // Insure required command parameters are populated...
                    if (!string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(key))
                    {

                        myDictionary.RemoveValue(key, value);  // Removed value from value list of dictionary key & key if it's the last value
                    }

                    else
                    {
                        // display error if REMOVE command is incomplete
                        Console.WriteLine("ERROR: REMOVE command is incomplete. It must contain a dictionary key and value");
                    }
                }

                // Handle REMOVEALL command
                else if (action == "REMOVEALL")
                {
                    // Insure required command parameters are populated...
                    if (!string.IsNullOrEmpty(key))
                    {

                        myDictionary.RemoveDictionaryKey(key);  // Remove all values from value list for this dictionary key
                    }

                    else
                    {
                        // Display error if REMOVEALL command is incomplete... 
                        Console.WriteLine("ERROR: REMOVEALL command is incomplete. It must contain a dictionary key");
                    }
                }

                // Handle MEMBERS command
                else if (action == "MEMBERS")
                    // Insure required command parameters exist
                    if (!string.IsNullOrEmpty(key))
                    {
                        myDictionary.ListDictionaryValuesByKey(key); // List all of the values (MEMBERS) for this dictionary key
                    }
                    else
                    {
                        // Display ERROR if command is incomplete... 
                        Console.WriteLine("ERROR: MEMBERS command is incomplete. It must contain a dictionary key");
                    }

                // Handle KEYS command...
                else if (action == "KEYS")
                {
                    myDictionary.ListKeys();  // List all of the dictionary's keys 
                }

                // Handle CLEAR command... 
                else if (action == "CLEAR")
                {
                    myDictionary.ClearDictionary();  // Completely clear the dictionary
                }

                // Handle KEYEXISTS command... 
                else if (action == "KEYEXISTS")
                {
                    // Insure the required command parameters exists
                    if (!String.IsNullOrEmpty(key))  
                    {
                        myDictionary.DoesKeyExist(key);  // Determine if this dictionary key exists or not... 
                    }
                    else
                    {
                        // Display error if KEYEXISTS command is incomplete... 
                        Console.WriteLine("ERROR: KEYEXISTS command is incomplete. It must contain a dictionary key");
                    }
                }

                // Handle MEMBEREXISTS command... 
                else if (action == "MEMBEREXISTS")
                {
                    // Insure all of the required parameters exist on the command...
                    if (!String.IsNullOrEmpty(key) && !String.IsNullOrEmpty(value))
                    {
                        myDictionary.DoesValueExist(key, value);  // Determine if this value exists in this dictionary key
                    }
                    else
                    {
                        // Display Error if command is incomplete.
                        Console.WriteLine("ERROR: MEMBEREXISTS command is incomplete. It must contain a dictionary key and value");
                    }
                }

                // Handle ALLMEMBERS command... 
                else if (action == "ALLMEMBERS")
                {
                    myDictionary.ListValues(); // List all of the individual values (members) in the dictionary... 
                }

                // Handle ITEMS command... 
                else if (action == "ITEMS")
                {
                    myDictionary.ListValuesByKey(); // List all of the keys and vlaues in the dictionary... 
                }

                // Display error if the command has not been recognized and it is not "Q" (quit)... 
                else if (action != "Q")
                {
                    Console.WriteLine("ERROR: Invalid Command");
                }

                // Create space between last command processing and the new command prompt...
                Console.WriteLine();

              // Process until "Q" is entered -> Quit
            } while (command != "Q");

            return;
        }
    }
}
