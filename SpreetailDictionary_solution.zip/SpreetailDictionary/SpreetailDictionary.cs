﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SpreetailDictionary.Interfaces;

namespace SpreetailDictionary.App
{
    public class SpreetailDictionary : ISpreetailDictionary
    {
        public Dictionary<string, List<string>> OurDictionary { get; set; }
        
        // Spreetail Constructor
        public SpreetailDictionary()
        {
            OurDictionary = new Dictionary<string, List<string>>();
        }

        //------------------------------
        // Add key/value to dictionary
        //------------------------------
        public void AddValue(string key, string value)
        {
            List<string> values = new List<string>();  // List of values for dictionary key
            try
            {
                // Append to existing key... 
                if (OurDictionary.ContainsKey(key))
                {
                    List<string> existing = OurDictionary[key]; // Get the existing list
                    if (!existing.Contains(value))  // See if values is already in the key's list
                    {
                        existing.Add(value);  // Add new value
                        OurDictionary[key] = existing; // Replace key's list with appended list
                        Console.WriteLine($"{key} {value} added"); // log action to console
                    }
                    else
                    {  
                        // Send ERROR that the values is already in the dictionary key's list
                        Console.WriteLine($"ERROR: {key} already has {value}"); 
                    }

                }

                // Add new dictionary key and value... 
                else
                {
                    values.Clear();  // clear working list of values
                    values.Add(value);  // add this new value to list of values
                    OurDictionary.Add(key, values); // add this key and list of values to dictionary
                    Console.WriteLine($"{key} {value} added"); // log action to console.
                }
            }

            catch (Exception exc)
            {
                //throw(Exception exc);
            }

        }

        //--------------------------------------------------
        // Remove a value from dictionary key's value list
        //--------------------------------------------------
        public void RemoveValue(string key, string value)
        {
            List<string> values = new List<string>();  // Value's list
            try
            {
                if (OurDictionary.ContainsKey(key)) // verify dictionary contains the key
                {
                    List<string> existing = OurDictionary[key];  // retrieve key's value list
                    if (existing.Contains(value)) // check values list for this value
                    {
                        existing.Remove(value); // remove this value from the list
                        OurDictionary[key] = existing; // replace key's value list after removal
                        Console.WriteLine($"{key} {value} removed"); // log action to console
                    }
                    else
                    {
                        // Log error if value not in dictionary key... 
                        Console.WriteLine($"ERROR: {value} not found in {key}");
                    }

                }
                else
                {
                    // log error if key not in dictionary
                    Console.WriteLine($"ERROR: {key} is not in the dictionary");
                }
            }

            catch (Exception exc)
            {
                //throw(Exception exc);
            }

        }

        //--------------------------------------------------
        // List all of the values in this dictionary key
        //--------------------------------------------------
        public void ListDictionaryValuesByKey(string key)
        {
            int x = 0; // counter
            if (OurDictionary.ContainsKey(key)) // verify dictionary contains key
            {
                List<string> existing = OurDictionary[key]; // get key's value list
                if (existing.Count > 0)  // if value list has entries
                {
                    foreach (var v in existing)  // for each value
                    {
                        x++; // increment counter
                        Console.WriteLine($"{x}) Key: {key} Value: {v}");  // display counter, key and value
                    }
                }

                else
                {
                    // Log ERROR if key value list is empty... 
                    Console.WriteLine($"ERROR: Key: {key} has no values");
                }
            }

            else
            {
                // Log ERROR if key not in dictionary
                Console.WriteLine($"ERROR: Key: {key} is not in the dictionary");
            }
        }

        //--------------------------------------------------
        // List all keys in the dictioary
        //--------------------------------------------------
        public void ListKeys()
        {
            int x = 0; // counter
            if (OurDictionary.Count > 0) // verify dictionary has keys
            {
                // Display list of the dictionary's keys... 
                Console.WriteLine($"The Keys in your dictionary are:");
                foreach (KeyValuePair<string, List<string>> pair in OurDictionary)
                {
                    x++;
                    Console.WriteLine($"{x}) {pair.Key}"); // display keys...
                }
            }
            else
            {
                // Log error if dictionary is empty (no keys)... 
                Console.WriteLine($"ERROR: Your dictionary is empty");
            }
        }

        //--------------------------------------------------
        // Remove a key (& values) from the dictionary
        //--------------------------------------------------
        public void RemoveDictionaryKey(string key)
        {
            if (OurDictionary.ContainsKey(key)) // verify key is in the dictionary
            {
                OurDictionary.Remove(key);  // remove the key
                Console.WriteLine($"{key} removed from dictionary"); // log action
            }
            else
            {
                // Log ERROR if key not in dictionary
                Console.WriteLine($"ERROR: Key: {key} does not exist in dictionary");
            }
        }

        //--------------------------------------------------
        // Completely clear the dictionary
        //--------------------------------------------------
        public void ClearDictionary()
        {
            OurDictionary.Clear();  // Clear dictionary
            Console.WriteLine("Dictionary has been cleared"); // log action
        }

        //--------------------------------------------------
        // See if the dicationary contains this key
        //--------------------------------------------------
        public void DoesKeyExist(string key)
        {
            if (OurDictionary.ContainsKey(key) ) // see if key in dictionary
            {
                Console.WriteLine("true"); // log result
            }
            // if key not in dictionary, log result
            else
            {
                Console.WriteLine("false");
            }
        }

        //--------------------------------------------------
        // See if this values is in this dictionary key
        //--------------------------------------------------
        public void DoesValueExist(string key, string value)
        {
            if (OurDictionary.ContainsKey(key))  // check for dictionary key
            {
                List<string> existing = OurDictionary[key]; // retrieve list of key's values
                if (existing.Contains(value)) // check for this value in the key list
                {
                    Console.WriteLine("true"); // log true if value found
                }
                else
                {
                    Console.WriteLine("false"); // log false if not found
                }
            }
            else
            {
                Console.WriteLine("false");  // log false if key not found
            }
        }

        //------------------------------------------------------------
        // Raw listing of all the values in the dicationary (no keys)
        //------------------------------------------------------------
        public void ListValues()
        {

           int x = 0; // counter
           if (OurDictionary.Count > 0)  // verify dictionary has keys & values
            {
                foreach (var key in OurDictionary.Keys) // loop thru all keys
                {
                    foreach (var value in OurDictionary[key]) // loop thru all values in each key
                    {
                        x++;  // increment counter
                        Console.WriteLine($"{x}) {value}"); // display counter & value
                    }
                }
            }
           else
            {
                Console.WriteLine("Dictionary is empty");  // log notice if dictionary is empty
            }
        }

        //--------------------------------------------------
        // List all key's and their values 
        //--------------------------------------------------
        public void ListValuesByKey()
        {

            int x = 0; // counter
            if (OurDictionary.Count > 0) // verify dictionary has entries
            {
                foreach (var key in OurDictionary.Keys) // loop thru keys
                {
                    foreach (var value in OurDictionary[key]) // loop thru this key's list of values
                    {
                        x++; // increment counter
                        Console.WriteLine($"{x}) {key} {value}"); // display counter, key and value
                    }
                }
            }
            else
            {
                Console.WriteLine("Dictionary is empty"); // log dictionary is empty... 
            }
        }
    }
}

