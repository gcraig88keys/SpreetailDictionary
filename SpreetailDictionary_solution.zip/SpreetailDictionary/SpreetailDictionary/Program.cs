﻿using System;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using SpreetailDictionary.App;
using SpreetailDictionary.Interfaces;

namespace SpreetailDictionary.App
{
    class Program
    {
        static void Main(string[] args)
        {
            IServiceCollection services = new ServiceCollection();
            Startup startup = new Startup();
            startup.ConfigureServices(services);
            IServiceProvider serviceProvider = services.BuildServiceProvider();

            SpreetailDictionary myDictionary = new SpreetailDictionary();
            
            
            string command = string.Empty;
            string status = string.Empty;
            string action = string.Empty;
            string key = string.Empty;
            string value = string.Empty;
            
            do
            {
                command = string.Empty;
                action = string.Empty;
                key = string.Empty;
                value = string.Empty;

                Console.WriteLine("Enter Command: KEYS, MEMBERS, ADD, REMOVE, REMOVEALL, CLEAR, KEYEXISTS, MEMBEREXISTS, ALLMEMBERS, ITEMS,");
                Console.WriteLine("or Q to stop");
                command = Console.ReadLine();

                //parse the command entered to determine action.
                string[] commandparts = command.Split(' ');

                if (commandparts.Length > 0)
                {
                    action = commandparts[0];
                }

                if (commandparts.Length > 1)
                {
                    key = commandparts[1];
                }

                if (commandparts.Length > 2)
                {
                    value = commandparts[2];
                }

                if (action == "ADD")
                {
                    if (!string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(key))
                    {
                        try
                        {
                            myDictionary.AddValue(key, value);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                    }

                    else
                    {
                        Console.WriteLine("ERROR: ADD command is incomplete. It must contain a dictionary key and value");
                    }

                }
                else if (action == "REMOVE")
                {
                    if (!string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(key))
                    {

                        myDictionary.RemoveValue(key, value);
                    }

                    else
                    {
                        Console.WriteLine("ERROR: REMOVE command is incomplete. It must contain a dictionary key and value");
                    }
                }

                else if (action == "REMOVEALL")
                {
                    if (!string.IsNullOrEmpty(key))
                    {

                        myDictionary.RemoveDictionaryKey(key);
                    }

                    else
                    {
                        Console.WriteLine("ERROR: REMOVEALL command is incomplete. It must contain a dictionary key");
                    }
                }

                else if (action == "MEMBERS")
                    if (!string.IsNullOrEmpty(key))
                    {
                        myDictionary.ListDictionaryValuesByKey(key);
                    }
                    else
                    {
                        Console.WriteLine("ERROR: MEMBERS command is incomplete. It must contain a dictionary key");
                    }

                else if (action == "KEYS")
                {
                    myDictionary.ListKeys();
                }

                else if (action == "CLEAR")
                {
                    myDictionary.ClearDictionary();
                }

                else if (action == "KEYEXISTS")
                {
                    if (!String.IsNullOrEmpty(key))
                    {
                        myDictionary.DoesKeyExist(key);
                    }
                    else
                    {
                        Console.WriteLine("ERROR: KEYEXISTS command is incomplete. It must contain a dictionary key");
                    }
                }

                else if (action == "MEMBEREXISTS")
                {
                    if (!String.IsNullOrEmpty(key) && !String.IsNullOrEmpty(value))
                    {
                        myDictionary.DoesValueExist(key, value);
                    }
                    else
                    {
                        Console.WriteLine("ERROR: MEMBEREXISTS command is incomplete. It must contain a dictionary key and value");
                    }
                }

                else if (action == "ALLMEMBERS")
                {
                    myDictionary.ListValues();
                }

                else if (action == "ITEMS")
                {
                    myDictionary.ListValuesByKey();
                }

                else if (action != "Q")
                {
                    Console.WriteLine("ERROR: Invalid Command");
                }

                Console.WriteLine();

            } while (command != "Q");

            return;

           // myDictionary.AddPair("Honda", "C-RV");
           // Console.WriteLine($"{myDictionary["Honda"]} added");
           
            //Console.WriteLine($"{myDictionary["Honda"]} added");
            //myDictionary.AddPair("Toyota", "RAV4");
            //Console.WriteLine($"{myDictionary["Toyota"]} added");
            //myDictionary.AddPair("Hyundai", "Tuscon");
            //Console.WriteLine($"{myDictionary["Hyundai"]} added");
            //myDictionary.AddPair("Volkswagen", "Tiguan");
            //Console.WriteLine($"{myDictionary["Volkswagen"]} added");
            //myDictionary.AddPair("Honda", "H-RV");

            //myDictionary.PrintKeys();

            //myDictionary.RemovePair("Honda");

            //myDictionary.PrintValues();

           // foreach (KeyValuePair<string, string> count in  myDictionary )
           // {
           //     Console.WriteLine($"Auto Make: {count.Key} \t Compact SUV: {count.Value}");
           // }


            //Console.WriteLine($"myDictionary has {myDictionary.Count} members");
            //string command = Console.ReadLine();
        
        
        }
    }
}
