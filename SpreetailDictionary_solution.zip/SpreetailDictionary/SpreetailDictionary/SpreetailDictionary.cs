﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SpreetailDictionary.Interfaces;

namespace SpreetailDictionary.App
{
    public class SpreetailDictionary : ISpreetailDictionary
    {
        public Dictionary<string, List<string>> OurDictionary { get; set; }
        

        public SpreetailDictionary()
        {
            OurDictionary = new Dictionary<string, List<string>>();
        }

        public void AddValue(string key, string value)
        {
            List<string> values = new List<string>();
            try
            {
                if (OurDictionary.ContainsKey(key))
                {
                    List<string> existing = OurDictionary[key];
                    if (!existing.Contains(value))
                    {
                        existing.Add(value);
                        OurDictionary[key] = existing;
                        Console.WriteLine($"{key} {value} added");
                    }
                    else
                    {
                        Console.WriteLine($"ERROR: {key} already has {value}");
                    }

                }
                else
                {
                    values.Clear();
                    values.Add(value);
                    OurDictionary.Add(key, values);
                    Console.WriteLine($"{key} {value} added");
                }
            }

            catch (Exception exc)
            {
                //throw(Exception exc);
            }

        }

        public void RemoveValue(string key, string value)
        {
            List<string> values = new List<string>();
            try
            {
                if (OurDictionary.ContainsKey(key))
                {
                    List<string> existing = OurDictionary[key];
                    if (existing.Contains(value))
                    {
                        existing.Remove(value);
                        OurDictionary[key] = existing;
                        Console.WriteLine($"{key} {value} removed");
                    }
                    else
                    {
                        Console.WriteLine($"ERROR: {value} not found in {key}");
                    }

                }
                else
                {
                    Console.WriteLine($"ERROR: {key} is not in the dictionary");
                }
            }

            catch (Exception exc)
            {
                //throw(Exception exc);
            }

        }

        public void ListDictionaryValuesByKey(string key)
        {
            int x = 0;
            if (OurDictionary.ContainsKey(key))
            {
                List<string> existing = OurDictionary[key];
                if (existing.Count > 0)
                {
                    foreach (var v in existing)
                    {
                        x++;
                        Console.WriteLine($"{x}) Key: {key} Value: {v}");
                    }
                }

                else
                {
                    Console.WriteLine($"ERROR: Key: {key} has no values");
                }
            }

            else
            {
                Console.WriteLine($"ERROR: Key: {key} is not in the dictionary");
            }
        }

        public void ListKeys()
        {
            int x = 0;
            if (OurDictionary.Count > 0)
            {
                Console.WriteLine($"The Keys in your dictionary are:");
                foreach (KeyValuePair<string, List<string>> pair in OurDictionary)
                {
                    x++;
                    Console.WriteLine($"{x}) {pair.Key}");
                }
            }
            else
            {
                Console.WriteLine($"ERROR: Your dictionary is empty");
            }
        }

        public void RemoveDictionaryKey(string key)
        {
            if (OurDictionary.ContainsKey(key))
            {
                OurDictionary.Remove(key);
                Console.WriteLine($"{key} removed from dictionary");
            }
            else
            {
                Console.WriteLine($"ERROR: Key: {key} does not exist in dictionary");
            }
        }

        public void ClearDictionary()
        {
            OurDictionary.Clear();
            Console.WriteLine("Dictionary has been cleared");
        }

        public void DoesKeyExist(string key)
        {
            if (OurDictionary.ContainsKey(key) )
            {
                Console.WriteLine("true");
            }
            else
            {
                Console.WriteLine("false");
            }
        }

        public void DoesValueExist(string key, string value)
        {
            if (OurDictionary.ContainsKey(key))
            {
                List<string> existing = OurDictionary[key];
                if (existing.Contains(value))
                {
                    Console.WriteLine("true");
                }
                else
                {
                    Console.WriteLine("false");
                }
            }
            else
            {
                Console.WriteLine("false");
            }
        }

        public void ListValues()
        {

           int x = 0;
           if (OurDictionary.Count > 0)
            {
                foreach (var key in OurDictionary.Keys)
                {
                    foreach (var value in OurDictionary[key])
                    {
                        x++;
                        Console.WriteLine($"{x}) {value}");
                    }
                }
            }
           else
            {
                Console.WriteLine("Dictionary is empty");
            }
        }
        public void ListValuesByKey()
        {

            int x = 0;
            if (OurDictionary.Count > 0)
            {
                foreach (var key in OurDictionary.Keys)
                {
                    foreach (var value in OurDictionary[key])
                    {
                        x++;
                        Console.WriteLine($"{x}) {key} {value}");
                    }
                }
            }
            else
            {
                Console.WriteLine("Dictionary is empty");
            }
        }
    }
}

