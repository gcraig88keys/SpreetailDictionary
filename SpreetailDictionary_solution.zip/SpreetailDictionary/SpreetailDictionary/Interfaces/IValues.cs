﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpreetailDictionary.Interfaces
{
    public interface IValues
    {
        List<string> values { get; set; }

    }
}
