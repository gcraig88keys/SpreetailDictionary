﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpreetailDictionary.Interfaces
{
    public interface ISpreetailDictionary
    {
        Dictionary<string, List<string>> OurDictionary { get; set; }
        
        void AddValue(string key, string value);
        
        void RemoveValue(string key, string value);

        void ListDictionaryValuesByKey(string key);

        void RemoveDictionaryKey(string key);

        void DoesKeyExist(string key);

        void DoesValueExist(string key, string value);

        void ClearDictionary();
        void ListKeys();

        void ListValues();

        void ListValuesByKey();
    }
}
