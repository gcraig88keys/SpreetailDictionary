﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SpreetailDictionary.Interfaces;
using SpreetailDictionary.App;

namespace SpreetailDictionary.App
{
    public class Startup
    {
    
        public Startup()
        {
         
        }

        public void ConfigureServices(IServiceCollection services)
        {
        services.AddSingleton<ISpreetailDictionary, SpreetailDictionary>();
        }
    }
}
