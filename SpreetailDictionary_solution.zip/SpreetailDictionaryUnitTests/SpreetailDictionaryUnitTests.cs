using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SpreetailDictionaryUnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
